(function ($) {
  $.extend($.summernote.lang, {
    'sr-RS': {
      font: {
        bold: 'Podebljano',
        italic: 'Kurziv',
        underline: 'Podvučeno',
        clear: 'Ukloni stilove fonta',
        height: 'Visina linije',
        strikethrough: 'Precrtano',
        size: 'Veličina fonta'
      },
      image: {
        image: 'Slika',
        insert: 'Umetni sliku',
        resizeFull: 'Puna veličina',
        resizeHalf: 'Umanji na 50%',
        resizeQuarter: 'Umanji na 25%',
        floatLeft: 'Uz levu ivicu',
        floatRight: 'Uz desnu ivicu',
        floatNone: 'Bez ravnanja',
        dragImageHere: 'Prevuci sliku ovde',
        selectFromFiles: 'Izaberi iz datoteke',
        url: 'Adresa slike',
        remove: 'Ukloni sliku'
      },
      video: {
        video: 'Video',
        videoLink: 'Veza ka videu',
        insert: 'Umetni video',
        url: 'URL video',
        providers: '(YouTube, Vimeo, Vine, Instagram, DailyMotion ili Youku)'
      },
      link: {
        link: 'Veza',
        insert: 'Umetni vezu',
        unlink: 'Ukloni vezu',
        edit: 'Uredi',
        textToDisplay: 'Tekst za prikaz',
        url: 'Internet adresa',
        openInNewWindow: 'Otvori u novom prozoru'
      },
      table: {
        table: 'Tabela'
      },
      hr: {
        insert: 'Umetni horizontalnu liniju'
      },
      style: {
        style: 'Stil',
        p: 'pni',
        blockquote: 'Citat',
        pre: 'Kod',
        h1: 'Zaglavlje 1',
        h2: 'Zaglavlje 2',
        h3: 'Zaglavlje 3',
        h4: 'Zaglavlje 4',
        h5: 'Zaglavlje 5',
        h6: 'Zaglavlje 6'
      },
      lists: {
        unordered: 'Obična lista',
        ordered: 'Numerisana lista'
      },
      options: {
        help: 'Pomoć',
        fullscreen: 'Preko celog ekrana',
        codeview: 'Izvorni kod'
      },
      paragraph: {
        paragraph: 'Paragraf',
        outdent: 'Smanji uvlačenje',
        indent: 'Povečaj uvlačenje',
        left: 'Poravnaj u levo',
        center: 'Centrirano',
        right: 'Poravnaj u desno',
        justify: 'Poravnaj obostrano'
      },
      color: {
        recent: 'Poslednja boja',
        more: 'Više boja',
        background: 'Boja pozadine',
        foreground: 'Boja teksta',
        transparent: 'Providna',
        setTransparent: 'Providna',
        reset: 'Opoziv',
        resetToDefault: 'Podrazumevana'
      },
      shortcut: {
        shortcuts: 'Prečice sa tastature',
        close: 'Zatvori',
        textFormatting: 'Formatiranje teksta',
        action: 'Akcija',
        paragraphFormatting: 'Formatiranje paragrafa',
        documentStyle: 'Stil dokumenta',
        extraKeys: 'Dodatne kombinacije'
      },
      history: {
        undo: 'Poništi',
        redo: 'Ponovi'
      }
    }
  });
})(jQuery);
